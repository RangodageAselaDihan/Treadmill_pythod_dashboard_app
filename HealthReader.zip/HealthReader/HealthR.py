# GP106 Group Project
# E/18/080

# importing numpy, tkinter, pillow, and datetime libraries
import numpy as np
import openpyxl as xl
# tkinter library for os design
from tkinter import *
# pillow library to add picture to os
from PIL import ImageTk, Image
# datetime library to handle date and time
from datetime import datetime

wb = xl.load_workbook('data.xlsx')
sheet = wb.active
# setting some variables
# variable select gender of user. For male and female the vales of Gender are 1, 2 respectively
RowNumber = 0
# [speed of Motor, radios of Motor, Weight, Height, Time passed, Age, Heart Rate, Gender]
data = [0, 0.02, 0, 0, 0, 0, 77, ""]
option = ["20% Decline", "19% Decline", "18% Decline", "17% Decline", "16% Decline", "15% Decline", "14% Decline",
          "13% Decline", "12% Decline", "11% Decline", "10% Decline", "09% Decline", "08% Decline", "07% Decline",
          "06% Decline", "05% Decline", "04% Decline", "03% Decline", "02% Decline", "01% Decline", "Level",
          "1% Incline", "2% Incline", "3% Incline", "4% Incline", "5% Incline", "6% Incline", "7% Incline",
          "8% Incline", "9% Incline", "10% Incline", "11% Incline", "12% Incline", "13% Incline", "14% Incline",
          "15% Incline", "16% Incline", "17% Incline", "18% Incline", "19% Incline", "20% Incline"]
optionN = [-20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5,
           6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
option1 = ["Male", "Female"]
option2 = ["Indoor", "Outdoor"]
# string where time detail placed
display = "0000000000"
counter = 66600

# this variable change with start, stop, restart this variable
run = False

# create main window by tkinter library
root = Tk()
root.title("HEALTH+")
var = IntVar()
variable = StringVar(root)
variable1 = StringVar(root)
variable2 = StringVar(root)
variable.set(option[0])
variable1.set(option1[0])
variable2.set(option2[0])
# creating main window with width 263, and height 430
root.minsize(width=1530, height=800)

ColNumber = sheet.max_column - 2
today = str(datetime.today().date())
print(sheet.max_column)
if sheet.cell(row=1, column=7).value is None:
    sheet.cell(row=1, column=7).value = today
elif sheet.cell(row=1, column=ColNumber).value != today:
    sheet.cell(row=1, column=ColNumber + 1).value = today
    print("pass")
wb.save("data.xlsx")


# counting function on time
def counter_label(label):
    def count():
        if run:
            global counter
            global display
            if counter == 66600:
                display = "Starting.."
            else:
                display = datetime.fromtimestamp(counter).strftime("%H:%M:%S")
                by_Enter()
            label['text'] = display
            label.after(1000, count)
            counter += 1
    count()


# stopwatch time starting function
def Start(label):
    global run
    run = True
    counter_label(label)
    start['state'] = "disabled"
    stop['state'] = 'normal'
    restart['state'] = "normal"


# stopwatch time stopping function
def Stop():
    global run
    start['state'] = "normal"
    stop['state'] = 'disabled'
    restart['state'] = "normal"
    run = False


# stopwatch time restarting function
def Reset(label):
    global counter
    counter = 66600
    if run == False:
        restart['state'] = "disabled"
        label['text'] = "welcome"
    else:
        label['text'] = "Starting"


# "Other Detail" button running function
def detail_reset():
    data[0] = EntryRpm.get()
    print(data[0], data[1], data[2], data[3])


# function related to mains screen "Enter" button
def by_Enter():
    global calories
    print(data)
    data[0] = float(EntryRpm.get())
    grade = optionN[option.index(variable.get())]
    Age = float(data[5])
    weight = float(data[2])
    height = float(data[3])
    time = int(display[0] + display[1]) * 360 + int(display[3] + display[4]) * 60 + int(
        display[6] + display[7])
    speed = ((float(data[0]) * np.pi * float(data[1]) ** 2) / 30)
    distance = (speed * time)
    step = (distance*250)/(speed*height*52)
    MHR = 208 - (0.7 * Age)
    RHR = data[6]
    Vo2max = 15.3 * (MHR / RHR)
    if Vo2max >= 56:
        CFF = 1
    elif 56 >= Vo2max >= 54:
        CFF = 1.01
    elif 54 >= Vo2max >= 52:
        CFF = 1.02
    elif 52 >= Vo2max >= 50:
        CFF = 1.03
    elif 50 >= Vo2max >= 48:
        CFF = 1.04
    elif 48 >= Vo2max >= 46:
        CFF = 1.05
    elif 46 >= Vo2max >= 44:
        CFF = 1.06
    else:
        CFF = 1.07

    if option2.index(variable2.get()) == 0:
        TF = 0
    elif option2.index(variable2.get()) == 1:
        TF = 0.84

    if -20 <= grade <= -15:
        calories = (((-0.01 * grade) + 0.5) * weight + TF) * distance * CFF*(1/1000)
    elif -15 <= grade <= -10:
        calories = (((-0.02 * grade) + 0.35) * weight + TF) * distance * CFF*(1/1000)
    elif -10 <= grade <= 0:
        calories = (((0.04 * grade) + 0.95) * weight + TF) * distance * CFF*(1/1000)
    elif 0 <= grade <= 10:
        calories = (((0.05 * grade) + 0.95) * weight + TF) * distance * CFF*(1/1000)
    elif 10 <= grade <= 15:
        calories = (((0.07 * grade) + 0.75) * weight + TF) * distance * CFF*(1/1000)
    elif grade >= 15:
        calories = (((0.09 * grade) + 0.55) * weight + TF) * distance * CFF*(1/1000)

    if data[7] == "Female":
        calories = calories*(213/276)
    LabelSpe['text'] = speed.__round__(3)
    LabelCal['text'] = calories.__round__(3)
    by_save(speed, distance, step)


def by_Login():
    global RowNumber
    for i in range(2, sheet.max_row + 1):
        name = EntryUser.get()
        if sheet.cell(row=i, column=1).value == name:
            data[2] = sheet.cell(row=i, column=2).value
            data[3] = sheet.cell(row=i, column=3).value
            data[5] = sheet.cell(row=i, column=4).value
            data[7] = sheet.cell(row=i, column=5).value
            RowNumber = i
    LabelWeight['text'] = str(data[2]) + " kg"
    LabelHeight['text'] = str(data[3]) + " m"


def by_NewUser():
    sheet.cell(row=sheet.max_row + 1, column=1).value = E1.get()
    sheet.cell(row=sheet.max_row, column=2).value = float(E4.get())
    sheet.cell(row=sheet.max_row, column=3).value = float(E3.get())
    sheet.cell(row=sheet.max_row, column=4).value = float(E2.get())
    sheet.cell(row=sheet.max_row, column=5).value = variable1.get()
    sheet.cell(row=sheet.max_row, column=6).value = "Walking Distance"
    sheet.cell(row=sheet.max_row + 1, column=6).value = "Running Distance"
    sheet.cell(row=sheet.max_row + 1, column=6).value = "Walking Steps"
    sheet.cell(row=sheet.max_row + 1, column=6).value = "Running Steps"
    wb.save('data.xlsx')


def by_save(speed, distance, step):
    global RowNumber
    global ColNumber
    CN = 0
    wd = 0; rd = 0; ws = 0; rs = 0
    for i in range(1, sheet.max_column):
        if sheet.cell(row=1, column=i).value == today:
            CN = i
            if sheet.cell(row=RowNumber, column=i).value is not None:
                wd = sheet.cell(row=RowNumber, column=i).value
            if sheet.cell(row=RowNumber + 1, column=i).value is not None:
                rd = sheet.cell(row=RowNumber + 1, column=i).value
            if sheet.cell(row=RowNumber + 2, column=i).value is not None:
                ws = sheet.cell(row=RowNumber + 2, column=i).value
            if sheet.cell(row=RowNumber + 3, column=i).value is not None:
                rs = sheet.cell(row=RowNumber + 3, column=i).value

    if speed >= 1.4:
        sheet.cell(row=RowNumber + 1, column=CN).value = distance + rd
        sheet.cell(row=RowNumber + 3, column=CN).value = step + rs
    else:
        sheet.cell(row=RowNumber, column=CN).value = distance + wd
        sheet.cell(row=RowNumber + 2, column=CN).value = step + ws
    wb.save('data.xlsx')


imgMainFrm = ImageTk.PhotoImage(Image.open("MainFrame.png"))
imgStepFrm = ImageTk.PhotoImage(Image.open("StepFrame.png"))
imgDeFrm = ImageTk.PhotoImage(Image.open("DetailFtame.png"))
imgCalFrm = ImageTk.PhotoImage(Image.open("CalFrame.png"))
imgAngleFrm = ImageTk.PhotoImage(Image.open("AngleFrame.png"))
imgSpeFrm = ImageTk.PhotoImage(Image.open("SpeedFrame.png"))
imgStFrm = ImageTk.PhotoImage(Image.open("StopFrame.png"))
imgRestart = ImageTk.PhotoImage(Image.open("restart.png"))
imgStart = ImageTk.PhotoImage(Image.open("start.png"))
imgStop = ImageTk.PhotoImage(Image.open("pause.png"))
imgSet = ImageTk.PhotoImage(Image.open("setting.png"))
imgHelp = ImageTk.PhotoImage(Image.open("help.png"))
imgReset = ImageTk.PhotoImage(Image.open("reset.png"))
imgLgFrm = ImageTk.PhotoImage(Image.open("LoginFrame.png"))
imgLogin = ImageTk.PhotoImage(Image.open("Login.png"))
imgNewU = ImageTk.PhotoImage(Image.open("NewUser.png"))
imgBackG = ImageTk.PhotoImage(Image.open("backg.png"))
cover = Label(root, padx=980, pady=500, bg="black", borderwidth=0)
Label1 = Label(root, image=imgMainFrm, bg="black", borderwidth=0)
Label2 = Label(root, image=imgStepFrm, bg="black", borderwidth=0)
Label3 = Label(root, image=imgCalFrm, bg="black", borderwidth=0)
Label4 = Label(root, image=imgSpeFrm, bg="black", borderwidth=0)
Label5 = Label(root, image=imgAngleFrm, bg="black", borderwidth=0)
Label6 = Label(root, image=imgDeFrm, bg="black", borderwidth=0)
Label8 = Label(root, image=imgStFrm, bg="black", borderwidth=0)
Label7 = Label(root, text="Welcome!", font="Verdana 40 bold", padx=50, bg="black", fg="#BBFF00")
Label9 = Label(root, image=imgLgFrm, bg="black", borderwidth=0)
Label10 = Label(root, image=imgBackG, bg="black", borderwidth=0)
LabelCal = Label(root, text="0.000", bg="black", borderwidth=0, fg="#BBFF00", font="time 20 bold")
LabelSpe = Label(root, text="0.000", bg="black", borderwidth=0, fg="#BBFF00", font="time 20 bold")
OptionAngle = OptionMenu(root, variable, *option)
OptionSurround = OptionMenu(root, variable2, *option2)

EntryRpm = Entry(root, font="time 20 bold")
EntryR = Label(root, font="time 20 bold", text="0.02 m")
LabelWeight = Label(root, text=str(data[2]), font="time 20 bold")
LabelHeight = Label(root, text=str(data[3]), font="time 20 bold")
E1 = Entry(root, font="time 20 bold")
E2 = Entry(root, font="time 20 bold")
E3 = Entry(root, font="time 20 bold")
E4 = Entry(root, font="time 20 bold")
EntryUser = Entry(root, font="time 20 bold")
f = Frame(root)
start = Button(f, command=lambda: Start(Label7), image=imgStart, borderwidth=0, bg="black")
stop = Button(f, state='disabled', command=lambda: Stop(), image=imgStop, borderwidth=0, bg="black")
restart = Button(f, font="time 7 bold", state="disabled", command=lambda: Reset(Label7), image=imgRestart,
                 borderwidth=0, bg="black")
setting = Button(f, image=imgSet, borderwidth=0, bg="black", command=by_Enter)
Help = Button(f, image=imgHelp, borderwidth=0, bg="black")
reset = Button(root, image=imgReset, borderwidth=0, bg="black", command=detail_reset)
enter = Button(root)
login = Button(root, image=imgLogin, borderwidth=0, bg="green", command=by_Login)
new = Button(root, image=imgNewU, borderwidth=0, bg="green", command=by_NewUser)
OptionGender = OptionMenu(root, variable1, *option1)
cover.place(x=0, y=0)
Label1.place(x=1010, y=10)
Label2.place(x=705, y=10)
Label3.place(x=435, y=10)
Label4.place(x=435, y=105)
Label5.place(x=435, y=200)
Label6.place(x=435, y=355)
Label7.place(x=15, y=120)
Label8.place(x=0, y=10)
Label9.place(x=0, y=250)
Label10.place(x=0, y=200)
LabelCal.place(x=580, y=29)
LabelSpe.place(x=580, y=125)
OptionAngle.place(x=565, y=220)
OptionSurround.place(x=345, y=201)

EntryRpm.place(x=800, y=450)
EntryR.place(x=800, y=495)
LabelWeight.place(x=800, y=540)
LabelHeight.place(x=800, y=585)
E1.place(x=120, y=520)
E2.place(x=120, y=580)
E3.place(x=120, y=640)
E4.place(x=120, y=700)
EntryUser.place(x=0, y=415)
f.place(x=440, y=300)
OptionGender.place(x=355, y=550)
start.pack(side="left")
stop.pack(side="left")
restart.pack(side="left")
setting.pack(side="left")
Help.pack(side="left")
reset.place(x=1120, y=670)
login.place(x=290, y=405)
new.place(x=20, y=460)

wb.save('data.xlsx')
root.mainloop()
