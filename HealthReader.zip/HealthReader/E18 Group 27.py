# importing libraries time and numpy
import time
import numpy as np

second = 0
Time = ""
run = False

# getting necessary input for calculation
rpm = float(input("Enter motor rotating speed: "))
r = float(input("Enter radius of motor: "))
w = float(input("Enter weight: "))
h = float(input("Enter height: "))
option = input("Enter option 'S' for start, 'R' for restart, 'T' for stop: ")


# function for printing and calculate other features
def calculate():
    global Time
    speed = (rpm * np.pi * r ** 2).__round__(3)
    distance = (speed * second).__round__(3)
    Time = str(second // 360) + ":" + str((second % 360) // 60) + ":" + str((second % 360) % 60)
    step = ((distance * 250) / (speed * h * 52)).__round__(3)
    calories = (0.035 * w + ((speed ** 2) / h) * 0.029 * w).__round__(3)
    print("Time = " + Time + " s")
    print("Speed of the track = " + str(speed) + " ms^-1")
    print("Distance walked or ran = " + str(distance) + " m")
    print("Steps moved = " + str(step) + " steps")
    print("Calories burnt = " + str(calories) + " cal")

# function for continuous flowing of time and checking to "start" or"terminate
while True:
    time.sleep(1)
    second += 1
    if option == "S":
        calculate()
    elif option == "R":
        Time = 0
        calculate()
    elif option == "T":
        print("It is terminated")
